const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const connectDB = require('./config/db');
const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const restaurantRoutes = require('./routes/restaurantRoutes');
const orderRoutes = require('./routes/orderRoutes');
require('dotenv').config();

const app = express();
const server = http.createServer(app);
const io = socketIo(server);

// Connect to MongoDB
connectDB();

// Middleware
app.use(express.json());

// Routes
app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api', restaurantRoutes);
app.use('/api', orderRoutes);

// WebSocket event for real-time tracking
io.on('connection', (socket) => {
    console.log('A user connected');
    socket.on('trackOrder', (orderId) => {
        // You can emit order status updates from the server
        socket.join(orderId);  // Join the room for the order
    });
});

// Function to emit real-time order status update
const emitOrderStatus = (orderId, status) => {
    io.to(orderId).emit('orderStatusUpdate', { status });
};

server.listen(5000, () => {
    console.log('Server running on port 5000');
});

module.exports = emitOrderStatus;
