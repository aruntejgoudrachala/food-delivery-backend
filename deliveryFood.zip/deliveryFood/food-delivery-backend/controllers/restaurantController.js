const Restaurant = require('../models/Restaurant');

// Create a new restaurant
exports.createRestaurant = async (req, res) => {
    const { name, location } = req.body;
    try {
        const newRestaurant = new Restaurant({ name, location });
        await newRestaurant.save();
        res.status(201).json(newRestaurant);
    } catch (error) {
        res.status(500).json({ msg: "Server error" });
    }
};

// Update restaurant details
exports.updateRestaurant = async (req, res) => {
    const { name, location } = req.body;
    try {
        let restaurant = await Restaurant.findById(req.params.restaurantId);
        if (!restaurant) {
            return res.status(404).json({ msg: "Restaurant not found" });
        }
        restaurant.name = name || restaurant.name;
        restaurant.location = location || restaurant.location;
        await restaurant.save();
        res.json(restaurant);
    } catch (error) {
        res.status(500).json({ msg: "Server error" });
    }
};

// Add menu item to a restaurant
exports.addMenuItem = async (req, res) => {
    const { name, description, price, availability } = req.body;
    try {
        let restaurant = await Restaurant.findById(req.params.restaurantId);
        if (!restaurant) {
            return res.status(404).json({ msg: "Restaurant not found" });
        }
        restaurant.menu.push({ name, description, price, availability });
        await restaurant.save();
        res.json(restaurant);
    } catch (error) {
        res.status(500).json({ msg: "Server error" });
    }
};

// Update menu item
exports.updateMenuItem = async (req, res) => {
    const { name, description, price, availability } = req.body;
    try {
        let restaurant = await Restaurant.findById(req.params.restaurantId);
        if (!restaurant) {
            return res.status(404).json({ msg: "Restaurant not found" });
        }

        let menuItem = restaurant.menu.id(req.params.itemId);
        if (!menuItem) {
            return res.status(404).json({ msg: "Menu item not found" });
        }

        menuItem.name = name || menuItem.name;
        menuItem.description = description || menuItem.description;
        menuItem.price = price || menuItem.price;
        menuItem.availability = availability !== undefined ? availability : menuItem.availability;

        await restaurant.save();
        res.json(menuItem);
    } catch (error) {
        res.status(500).json({ msg: "Server error" });
    }
};
