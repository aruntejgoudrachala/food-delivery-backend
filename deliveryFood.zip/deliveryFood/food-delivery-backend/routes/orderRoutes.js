const express = require('express');
const { placeOrder, getOrderDetails, updateOrderStatus } = require('../controllers/orderController');
const { authMiddleware } = require('../middleware/authMiddleware');

const router = express.Router();

// Order routes
router.post('/orders', authMiddleware, placeOrder);
router.get('/orders/:orderId', authMiddleware, getOrderDetails);
router.put('/orders/:orderId/status', authMiddleware, updateOrderStatus);

module.exports = router;
