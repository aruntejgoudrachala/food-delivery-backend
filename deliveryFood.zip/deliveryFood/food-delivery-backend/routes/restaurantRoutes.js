const express = require('express');
const {
    createRestaurant,
    updateRestaurant,
    addMenuItem,
    updateMenuItem
} = require('../controllers/restaurantController');
const { authMiddleware } = require('../middleware/authMiddleware');

const router = express.Router();

// Restaurant management
router.post('/restaurants', authMiddleware, createRestaurant);
router.put('/restaurants/:restaurantId', authMiddleware, updateRestaurant);

// Menu management
router.post('/restaurants/:restaurantId/menu', authMiddleware, addMenuItem);
router.put('/restaurants/:restaurantId/menu/:itemId', authMiddleware, updateMenuItem);

module.exports = router;
