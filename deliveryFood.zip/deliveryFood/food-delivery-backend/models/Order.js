const mongoose = require('mongoose');

const OrderSchema = new mongoose.Schema({
    user: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'User',
        required: true
    },
    restaurant: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Restaurant',
        required: true
    },
    items: [{
        name: String,
        price: Number,
        quantity: Number
    }],
    deliveryAddress: {
        type: String,
        required: true
    },
    totalCost: {
        type: Number,
        required: true
    },
    status: {
        type: String,
        enum: ['Pending', 'Confirmed', 'In Progress', 'Out for Delivery', 'Delivered'],
        default: 'Pending'
    },
    estimatedDeliveryTime: {
        type: Date
    }
});

module.exports = mongoose.model('Order', OrderSchema);
